This is a project that I did for my Java Class.
It includes three games one of which being minesweeper.

To run just double click the "Game Group.jar" file

To view the source code visit https://github.com/CThompson01/JavaChapter-15