# RNGGit
This program was made to generate images like the default github profile pictures.
It generates a 500x500 image that is symmetrical.
